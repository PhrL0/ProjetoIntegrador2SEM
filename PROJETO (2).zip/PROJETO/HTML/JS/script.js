// Configuração do gráfico de produção
const ctx1 = document.getElementById('graficoProducao').getContext('2d');
const graficoProducao = new Chart(ctx1, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [{
            label: 'Produção',
            data: [120, 150, 180, 200, 170, 190],
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                ticks: {
                    color: '#FFFFFF' // Cor branca para os rótulos do eixo X
                }
            },
            y: {
                ticks: {
                    color: '#FFFFFF' // Cor branca para os rótulos do eixo Y
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: '#FFFFFF' // Cor branca para a legenda
                }
            }
        }
    }
});

// Configuração do gráfico de vendas
const ctx2 = document.getElementById('graficoVendas').getContext('2d');
const graficoVendas = new Chart(ctx2, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Abr', 'Mai', 'Jun'],
        datasets: [{
            label: 'Vendas',
            data: [100, 130, 140, 160, 150, 180],
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            x: {
                ticks: {
                    color: '#FFFFFF' // Cor branca para os rótulos do eixo X
                }
            },
            y: {
                ticks: {
                    color: '#FFFFFF' // Cor branca para os rótulos do eixo Y
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: '#FFFFFF' // Cor branca para a legenda
                }
            }
        }
    }
});

// Redireciona para a página de Produção Mensal
function producao(){
    window.location.href = "../HTML/HTML-2/producao.html"; 
}

// Redireciona para a página de Desempenho
function desempenho(){
    window.location.href = "../HTML/HTML-2/desempenho.html";
}

// Redireciona para a página de Estoque
function estoque(){
    window.location.href = "../HTML/HTML-2/estoque.html";
}